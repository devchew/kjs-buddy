export default {
  plugins: {
    autoprefixer: {},
  },
};
